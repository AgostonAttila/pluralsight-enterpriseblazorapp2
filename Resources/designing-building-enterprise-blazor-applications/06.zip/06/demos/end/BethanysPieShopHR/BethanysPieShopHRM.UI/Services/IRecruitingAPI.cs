﻿namespace BethanysPieShopHRM.UI.Services
{
    internal interface IRecruitingAPI
    {
    }
}